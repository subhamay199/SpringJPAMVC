package com.cg.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@Component("bankingServices")
public  class BankingServicesImpl implements BankingServices{
	@Autowired
	AccountDAO customerData1;
	@Autowired
	TransactionDAO transactionDAO;
	private final static float minBalance=500;
	private final static int minAttempt=3;	
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(initBalance<=minBalance)
			throw new InvalidAmountException("maintain minimum balance");
		Account cust = customerData1.save(new Account(accountType,initBalance));
		transactionDAO.save(new Transaction(initBalance, "Deposit",cust));
		return cust;
	}
	public float withdrawAmount(int accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account customers=null;
		customers=getAccountDetails(accountNo);
		if(customers.getAccountStatus().equalsIgnoreCase("BLOCKED")) {
			throw new AccountBlockedException("account is blocked");
		}
		else if(customers.getPinNumber()!=pinNumber) {
			Account.incrementAttempt();
			System.out.println("No. Of Pin Attempts remaining "+(minAttempt-customers.getAttempt()));
			if(customers.getAttempt()==minAttempt) {
				customers.setAccountStatus("Blocked");
				throw new AccountBlockedException("Due to 3 Incorrect pins Account is blocked");
			}
			else {
				throw new InvalidPinNumberException("invalid pin number");
			}
		}
		else if(customers.getAccountBalance()-amount<=minBalance) {
			throw new InsufficientAmountException("insufficient amount");
		}
		else {
			customers.setAccountBalance(customers.getAccountBalance()-amount);
		}
		customerData1.save(customers);
		transactionDAO.save(new Transaction(amount, "Withdraw",customers));
		return customers.getAccountBalance();
	}

	public Account getAccountDetails(int accountNo) throws AccountNotFoundException, BankingServicesDownException {

		return customerData1.findById(accountNo).orElseThrow(()->new AccountNotFoundException("Account not found for accountNo "+accountNo));
	}

	public List<Account> getAllAccountDetails() throws BankingServicesDownException {

		List<Account>customers=customerData1.findAll();
		return customers;
	}

	public List<Transaction> getAccountAllTransactions(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		List<Transaction> transaction=transactionDAO.findAll();
		return transaction;
	}

	public String accountStatus(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException,AccountBlockedException {
		Account customers=customerData1.findById((int)accountNo).orElseThrow(()->new AccountNotFoundException("Account not found for accountNo "+accountNo));
		if(customers.getAccountStatus().equalsIgnoreCase("BLOCKED!"))
			throw new AccountBlockedException("account is blocked");
		return customers.getAccountStatus();
	}

	public float depositAmount(int accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customers=null;
		customers=getAccountDetails(accountNo);
		int save1=(int) (customers.getAccountBalance()+amount);
		if(customers.getAccountStatus().equalsIgnoreCase("BLOCKED!"))
			throw new AccountBlockedException("account is blocked");
		else
			customers.setAccountBalance(customers.getAccountBalance()+amount);
		customerData1.save(customers);
		transactionDAO.save(new Transaction(amount, "Deposit",customers));
		return customers.getAccountBalance() ;
	}

	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo=null;
		Account customerFrom=null;
		customerTo=getAccountDetails((int) accountNoTo);
		customerFrom=getAccountDetails((int) accountNoFrom);
		if(customerFrom.getAccountBalance()-transferAmount<=minBalance)
			throw new InsufficientAmountException("insufficient amount");
		if(customerFrom.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException("invalid pin");
		else {
			customerFrom.setAccountBalance(withdrawAmount((int) customerFrom.getAccountNo(),transferAmount,customerFrom.getPinNumber()));
			customerTo.setAccountBalance(depositAmount((int) customerTo.getAccountNo(),transferAmount));
			customerData1.save(customerTo);
			customerData1.save(customerFrom);
			return true;
		}
	}

	@Override
	public Account openAccount(Account account) {
		account=customerData1.save(account);
		return account;
	}
}
