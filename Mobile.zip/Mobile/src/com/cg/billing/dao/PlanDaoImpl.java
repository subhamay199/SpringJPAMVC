package com.cg.billing.dao;

import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.billing.beans.Plan;


public class PlanDaoImpl implements PlanDAO{
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");

	@Override
	public Plan save(Plan plans) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.persist(plans);
		entityManager.getTransaction().commit();
		entityManager.close();
		
		return plans;		
	}

	@Override
	public boolean update(Plan plans) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.merge(plans);
		entityManager.getTransaction().commit();
		entityManager.close();
				return false;
	}

	@Override
	public Plan findOne(int planID) {
		return entityManagerFactory.createEntityManager().find(Plan.class,planID );
	
	}

	@Override
	public Map<Integer, Plan> findAll() {
		Query query=entityManagerFactory.createEntityManager().createNamedQuery("from Transaction t",Plan.class);
		return  (Map<Integer, Plan>) query.getResultList();		
	}

}
